package com.example.aulasqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class PessoaDAO {
    private Conexao conexao;
    private SQLiteDatabase banco;

    public PessoaDAO(Context context){ //context p criar conexao
        this.conexao = new Conexao(context);
        banco = conexao.getWritableDatabase(); //bd com suporte a escrita
    }

    //INSERT
    public String inserir(Pessoa pessoa) {
        //criando objeto para insercao no BD
        ContentValues valores = new ContentValues();
        valores.put("nome", pessoa.getNome()); //nome da coluna no BD, valor da variavel
        valores.put("endereco", pessoa.getEndereco()); //coluna,valor

        return "Inseridos: "+banco.insert("pessoa",null,valores);//(nome do BD,null,valores)
    }
    //SELECT
    public ArrayList<Pessoa> obterTodos(){

        ArrayList<Pessoa> lista = new ArrayList<Pessoa>();

        //SELECT * FROM pessoa;
        String[] colunas = new String[]{"nome","endereco"};
        Cursor rs = banco.query("pessoa",colunas,null,null,null,null,null);

        while(rs.moveToNext()){
            Pessoa p = new Pessoa();
            p.setNome(rs.getString(0));//nome=0  endereco=1
            p.setEndereco(rs.getString(1));
            lista.add(p);
        }
        return lista;
    }
}
