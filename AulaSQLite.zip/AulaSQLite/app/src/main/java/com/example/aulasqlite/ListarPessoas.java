package com.example.aulasqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class ListarPessoas extends AppCompatActivity {

    private ListView listView;
    private PessoaDAO dao;
    private ArrayList<Pessoa> lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar_pessoas);

        listView = findViewById(R.id.listview);
        dao = new PessoaDAO(this);

        lista = dao.obterTodos();
        ArrayAdapter<Pessoa> adaptador = new ArrayAdapter<Pessoa>(this,android.R.layout.simple_list_item_1,lista);

        listView.setAdapter(adaptador);
    }
}
