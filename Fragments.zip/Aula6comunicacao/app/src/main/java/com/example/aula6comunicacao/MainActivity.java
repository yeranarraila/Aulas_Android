package com.example.aula6comunicacao;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements Icomunicacao {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void resposta(double texto) {//metodo invocado pelo FragmentEntrada
        FragmentManager fm = getSupportFragmentManager();//gerenciar os fragments
        FragmentSaida fs = (FragmentSaida) fm.findFragmentById(R.id.fragment2);//endereço do fragment de saida
        fs.updateDados(texto);
    }
}