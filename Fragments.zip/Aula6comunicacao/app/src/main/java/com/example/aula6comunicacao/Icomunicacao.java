package com.example.aula6comunicacao;

public interface Icomunicacao {
    public void resposta (double texto);

}