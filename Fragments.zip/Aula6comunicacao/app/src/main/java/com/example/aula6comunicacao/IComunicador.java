package com.example.aula6comunicacao;

public interface IComunicador {
    public void resposta(String texto);
}
