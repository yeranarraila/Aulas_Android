package com.example.aula6comunicacao;


import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class FragmentSaida extends Fragment {
    private TextView txResultado;//id resultado
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_fragment_saida, container, false);
    }
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        txResultado = getActivity().findViewById(R.id.resultado);//recuperando o txView
    }
    public void updateDados(double nome){
        txResultado.setText(String.valueOf(nome));
    }

}