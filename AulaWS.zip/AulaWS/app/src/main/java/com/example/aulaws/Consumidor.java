package com.example.aulaws;

import android.widget.TextView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Consumidor {

    public void consomeWS(TextView resposta, TextView entrada){

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://api.github.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        IGitService conn = retrofit.create(IGitService.class);

        Call<Usuario> call = conn.getUsuario(entrada.getText().toString());

        call.enqueue(new Callback<Usuario>() {
            @Override
            public void onResponse(Call<Usuario> call, Response<Usuario> response) {
                if(response.code() == 200) { //HTTP: OK!
                    Usuario usuario = response.body(); //a resposta completa do ws
                    if (usuario.getEmail() != null) {
                        resposta.setText(usuario.getEmail());
                    } else {
                        resposta.setText("Email não informado!");
                    }
                }else{
                    resposta.setText("Usuário não cadastrado na plataforma!");
                }
            }

            @Override
            public void onFailure(Call<Usuario> call, Throwable t) {
                resposta.setText(t.getMessage());
            }
        });

    }
}
