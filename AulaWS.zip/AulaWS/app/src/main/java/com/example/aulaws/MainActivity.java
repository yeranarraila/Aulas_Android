package com.example.aulaws;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void buscarUsuario(View view){

        TextView txJson = findViewById(R.id.resposta);
        TextView txUser = findViewById(R.id.entrada);

        Consumidor consumidor = new Consumidor();
        consumidor.consomeWS(txJson,txUser);


    }

}
