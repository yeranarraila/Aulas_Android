package com.example.aulaws;

public class Usuario {

    private long id;
    private String login;
    private String name;
    private String email;

    public long getId() {
        return id;
    }

    public String getLogin() {
        return login;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }
}
